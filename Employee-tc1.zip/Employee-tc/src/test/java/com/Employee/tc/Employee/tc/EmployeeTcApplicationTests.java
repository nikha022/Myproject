package com.Employee.tc.Employee.tc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeTcApplicationTests {

	@Test
	void contextLoads() {
	}

}
