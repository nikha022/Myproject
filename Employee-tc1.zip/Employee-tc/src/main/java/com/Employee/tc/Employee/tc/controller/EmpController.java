package com.Employee.tc.Employee.tc.controller;

import java.awt.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Employee.tc.Employee.tc.service.EmpService;


@RestController
public class EmpController {
	
	@Autowired
	EmpService service;
	
	
	
	@GetMapping("/ezz")
	public List getempRecords() {
		
		java.util.List em1 =service.getempRecords();	
		
		return null;
	}
	
}
