package com.Employee.tc.Employee.tc.service;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Employee.tc.Employee.tc.dao.Studentdao;

@Service
public class EmpService {

	@Autowired
	Studentdao dao;
	
	public java.util.List getempRecords() {

		
		return dao.getempRecords();
	}

	
	
	
}
