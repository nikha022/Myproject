package com.Employee.tc.Employee.tc.dao;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

import com.Employee.tc.Employee.tc.entity.Employee;

@Repository
public class Studentdao {

	
	@Autowired
	SessionFactory sf;
	
	@SuppressWarnings("rawtypes")
	public java.util.List getempRecords() {

		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(Employee.class);
				java.util.List list = criteria.list();
				
				session.close();
				return list;
	}

}
